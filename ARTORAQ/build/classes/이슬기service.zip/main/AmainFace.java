package service.main;

public interface AmainFace {

}
