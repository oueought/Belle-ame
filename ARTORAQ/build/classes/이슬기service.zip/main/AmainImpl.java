package service.main;

public class AmainImpl {

}
