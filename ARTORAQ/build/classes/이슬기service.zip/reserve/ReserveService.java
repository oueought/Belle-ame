package service.reserve;

import javax.servlet.http.HttpServletRequest;

import dto.reserve.Reserve;

public interface ReserveService {
	
	
	public Reserve getParam(HttpServletRequest req);
	
	
	
	
}
